__version__ = '0.1.0'
__author__ = 'imAnesYT'
__url__ = 'https://github.com/imAnesYT/buildsnap'